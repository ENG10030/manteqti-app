# إصلاح رفع الصور والفيديوهات من الجهاز

## التغييرات

### 1. إضافة FileUpload Component
- تم استبدال حقول إدخال URL بـ FileUpload component
- يدعم السحب والإفلات (Drag & Drop)
- يدعم رفع ملفات متعددة
- يعرض شريط تقدم أثناء الرفع
- يعرض معاينة للصور والفيديوهات

### 2. الملفات المعدلة

```
src/app/page.tsx
  - إضافة import FileUpload component
  - استبدال قسم الصور في نموذج الإضافة بـ FileUpload
  - استبدال قسم الفيديوهات في نموذج الإضافة بـ FileUpload
  - استبدال قسم الصور في نموذج التعديل بـ FileUpload
  - استبدال قسم الفيديوهات في نموذج التعديل بـ FileUpload

src/components/file-upload.tsx
  - Component لرفع الصور والفيديوهات من الجهاز
  - يدعم Cloudinary لرفع الملفات
```

---

## 🚀 خطوات التثبيت

### الطريقة 1: نسخ الملفات مباشرة

1. افتح: `https://github.com/ENG10030/manteqti-app/edit/main/src/app/page.tsx`
2. احذف كل المحتوى
3. الصق محتوى الملف الجديد من `src/app/page.tsx`
4. اضغط **Commit changes**

5. تأكد من وجود ملف `src/components/file-upload.tsx` في المشروع

---

## ✅ بعد التثبيت

1. انتظر 1-2 دقيقة حتى يعيد Vercel البناء
2. افتح: `https://manteqti-app.vercel.app`
3. سجل دخول كمطور
4. اضغط "إضافة شقة"
5. ستجد قسم لرفع الصور والفيديوهات من جهازك! ✅

---

## 📋 المتطلبات

تأكد من وجود Environment Variables على Vercel:
```
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
```

---

## الميزات الجديدة

✅ رفع الصور من الجهاز (Drag & Drop)
✅ رفع الفيديوهات من الجهاز
✅ معاينة الصور قبل الإرسال
✅ شريط تقدم أثناء الرفع
✅ حذف الصور/الفيديوهات
✅ حد أقصى 5 صور و 3 فيديوهات
✅ حد أقصى 50MB للملف

---

تم إنشاء هذا الملف بواسطة Z.ai Code
