# إصلاح مشكلة زر التفاصيل

## المشكلة
زر "التفاصيل" لا يفتح نافذة التفاصيل عند الضغط عليه.

## السبب
الـ API يعيد `images`, `videos`, `amenities` كـ JSON string، لكن الكود يتعامل معها كـ array. هذا يسبب خطأ JavaScript يمنع الـ Modal من الظهور.

## الحل
تم إضافة دالة `processApartment` لتحويل JSON strings إلى arrays عند جلب البيانات.

---

## 📁 الملف المطلوب تعديله

```
src/app/page.tsx
```

---

## 🚀 خطوات التثبيت

### الطريقة 1: نسخ الكود مباشرة

1. افتح: `https://github.com/ENG10030/manteqti-app/edit/main/src/app/page.tsx`

2. ابحث عن هذا الكود (حوالي السطر 100-102):
```typescript
interface Toast { id: string; message: string; type: 'success' | 'error' | 'info'; }
interface User { id: string; identifier: string; name: string; }

// Confirm Dialog Component
```

3. استبدله بـ:
```typescript
interface Toast { id: string; message: string; type: 'success' | 'error' | 'info'; }
interface User { id: string; identifier: string; name: string; }

// Helper function to parse JSON string to array
function parseJsonArray(value: string | string[] | undefined): string[] {
  if (!value) return [];
  if (Array.isArray(value)) return value;
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

// Helper function to process apartment data (convert JSON strings to arrays)
function processApartment(apt: any): Apartment {
  return {
    ...apt,
    images: parseJsonArray(apt.images),
    videos: parseJsonArray(apt.videos),
    amenities: parseJsonArray(apt.amenities),
  };
}

// Confirm Dialog Component
```

4. ثم ابحث عن `fetchApartments` (حوالي السطر 289):
```typescript
const fetchApartments = async () => {
  try {
    const res = await fetch('/api/apartments');
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to fetch');
    setApartments(data);
    setAllApartments(data);
    setLoading(false);
  } catch (err: any) {
    setError(err.message);
    setLoading(false);
  }
};
```

5. استبدله بـ:
```typescript
const fetchApartments = async () => {
  try {
    const res = await fetch('/api/apartments');
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to fetch');
    // Process apartments to convert JSON strings to arrays
    const processedData = data.map(processApartment);
    setApartments(processedData);
    setAllApartments(processedData);
    setLoading(false);
  } catch (err: any) {
    setError(err.message);
    setLoading(false);
  }
};
```

6. اضغط **Commit changes**

---

### الطريقة 2: تحميل الملف كاملاً

1. حمّل ملف `page.tsx` من هذا المجلد
2. اذهب إلى: `https://github.com/ENG10030/manteqti-app/edit/main/src/app/page.tsx`
3. احذف كل المحتوى
4. الصق محتوى الملف الجديد
5. اضغط **Commit changes**

---

## ✅ بعد التعديل

1. انتظر 1-2 دقيقة حتى يعيد Vercel البناء
2. افتح: `https://manteqti-app.vercel.app`
3. اضغط على زر "التفاصيل" - سيعمل الآن! ✅

---

تم إنشاء هذا الملف بواسطة Z.ai Code
